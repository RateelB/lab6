from django.db import models

# Create your models here.
class Course(models.Model):
   name=models.CharField(max_length=100)

   def __str__(self):
      return f"{self.name}"
    
class Student(models.Model):
   firstName= models.CharField(max_length=64)
   lastName=models.CharField(max_length=64)
   email=models.CharField(max_length=64)
   age=models.IntegerField()
   courses=models.ManyToManyField(Course,blank=True,related_name='students')

   def __str__(self):
      return f"{self.firstName}{self.lastName}"

