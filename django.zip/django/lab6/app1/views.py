from django.shortcuts import render
from django.urls import reverse
from django.http import HttpResponseRedirect
from django import forms
from .models import Student,Course

# Create your views here.
class StudentForm(forms.ModelForm):
    class Meta:
        model=Student
        fields=['firstName','lastName','email','age']

class CourseForm(forms.ModelForm):
    class Meta:
        model=Course
        fields=['name']

def students(request):
    student=Student.objects.all()
    if request.method =='POST':
        form=StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('students'))
    else:
        form=StudentForm()
    return render(request,'app1/students.html',{'student':student,'form':form})   
     
def courses(request):
    course=Course.objects.all()
    if request.method =='POST':
        form=CourseForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('courses'))
    else:
        form=CourseForm()
    return render(request,'app1/courses.html',{'course':course,'form':form})

def detail(request,student_id):
    student=Student.objects.get(id=student_id)
    available_courses=Course.objects.exclude(students=student)
    if request.method =='POST':
        selected_course=request.POST.get('course')
        if selected_course:
            student.courses.add(Course.objects.get(id=selected_course))
            return HttpResponseRedirect(reverse('students'))
    return render(request,'app1/detail.html',{'student':student,'available_courses':available_courses})
